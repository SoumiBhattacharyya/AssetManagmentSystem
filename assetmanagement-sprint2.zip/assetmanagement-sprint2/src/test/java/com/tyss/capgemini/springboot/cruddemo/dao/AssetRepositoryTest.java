package com.tyss.capgemini.springboot.cruddemo.dao;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.assetmanagement.application.DAO.AssetRepository;
import com.capgemini.assetmanagement.application.entity.Asset;
import com.capgemini.assetmanagement.application.entity.Assets;

public class AssetRepositoryTest {

	@Autowired
	private AssetRepository assetRepository;

	Assets assets;

	@Autowired
	public AssetRepositoryTest(AssetRepository theAssetRepository) {
		assetRepository = theAssetRepository;
	}

	@Test
	void getAllAsset() {

		List<Asset> demo = assetRepository.getAllAssets();
		assertNotNull(demo);

	}

	@Test
	void getAssetById() {
		assetRepository.getAssetById(101);
	}

}
