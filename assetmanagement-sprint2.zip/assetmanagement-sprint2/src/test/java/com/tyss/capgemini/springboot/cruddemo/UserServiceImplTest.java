package com.tyss.capgemini.springboot.cruddemo;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.event.annotation.BeforeTestClass;

import com.capgemini.assetmanagement.application.entity.Asset;
import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.Users;
import com.capgemini.assetmanagement.application.service.UserService;

@SpringBootTest
public class UserServiceImplTest {
	
	User user;
	Users theUsers;

	@Autowired
	private UserService userService;
	
	@Test
	void saveUsers() {
		theUsers = new Users();
		theUsers.setUserId(0);
		theUsers.setFullName("Rick Bhatt");
		theUsers.setEmail("rick@gmail.com");
		theUsers.setAddress("Kanailal Avenue , Chandannagar");
		theUsers.setPassword("Rick@123");
		theUsers.setConfirmPassword("Rick@123");
		theUsers.setUserImage("https://cdn.pixabay.com/photo/2015/06/22/08/40/child-817373__340.jpg");
		theUsers.setRole("CUSTOMER");
		theUsers.setMobile("9830489086");

		userService.save(theUsers);
		

	}

	@Test
	void addUserTest() {
		User demo = userService.getUserById(152);
		assertNotNull(demo);
	}

	@Test
	void getUserById() {
		userService.getUserById(152);
	}

	@Test
	void getAllUsers() {
		List<User> demo = userService.getAllUsers();
		assertNotNull(demo);
	}

	
//	void updateUsers() {
//	User demo = userService.getUserById(151);
//	Users demo2 = userService.
//		user.setFullName("Rick Bhattacharyya");
//		user.setAddress("UK");
//		userService.save(user);
//
//	}

	@Test
	void getUserByEmail() {
		user =userService.findByEmail("rick@gmail.com");
		assertNotNull(user);
	}

	@Test
	void getCustomers() {
		List<User> demo = userService.getCustomers("CUSTOMER");
		assertNotNull(demo);
		

	}
	
	
	@Test
	void deleteUserById() {
	 User demo = userService.getUserById(152);
	 assertNotNull(demo);
			userService.deleteById(demo.getUserId());
		User demo1 = userService.getUserById(152);
		assertNull(demo1);
		

	}

}
