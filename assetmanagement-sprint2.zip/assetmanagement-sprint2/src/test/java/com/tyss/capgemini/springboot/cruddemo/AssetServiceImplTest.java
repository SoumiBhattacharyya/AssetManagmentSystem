  package com.tyss.capgemini.springboot.cruddemo;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.assetmanagement.application.entity.Asset;
import com.capgemini.assetmanagement.application.entity.Assets;
import com.capgemini.assetmanagement.application.service.AssetService;

@SpringBootTest
public class AssetServiceImplTest {
	Asset asset;
	Assets assets;

	@Autowired
	private AssetService assetService;
	
	@BeforeEach
	void saveAssets() {
		assets=new Assets();
//		assets.setAssetId(0);
		assets.setAssetName("Book");
		assets.setAssetPrice(657.34);
		assets.setAssetImageUrl("https://cdn.pixabay.com/photo/2016/09/10/17/18/book-1659717__340.jpg");
		assets.setAssetDescription("Best for learning !");
		
		assetService.save(assets);
		
//		return assets;
		
	}
	@Test
	void addAssetTest() {
		assertNotNull(assets);
	}
	
	@Test
	void getAllAssetsTest() {
		List<Asset> asset = assetService.getAllAssets();
		assertNotNull(asset);
	}
	
	@Test
	void searchByIdTest() {
		assetService.getAssetById(assets.getAssetId());	
	}
	
	@Test
	void deleteByIdTest() {
		assetService.deleteById(assets.getAssetId());
	}
	
	
	
}
