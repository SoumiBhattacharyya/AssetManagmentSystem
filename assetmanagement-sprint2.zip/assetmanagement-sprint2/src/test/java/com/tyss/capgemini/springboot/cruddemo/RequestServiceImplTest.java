package com.tyss.capgemini.springboot.cruddemo;

import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.Requests;
import com.capgemini.assetmanagement.application.service.RequestService;

public class RequestServiceImplTest {

	Request request;
	Requests theRequests;

	@Autowired
	RequestService requestService;

	@Test
	void save() {
		request = new Request();
		request.setRequestId(0);
		request.setAssetId(101);
		request.setAssetName("Guitar");
		request.setAssetQuantity(23);
		request.setEmployeeId(122);

		requestService.save(request);
	}

//	@Test
//	void addRequest() {
//		assertNotNull(request);
//	}

}
