package com.capgemini.assetmanagement.application.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.application.entity.Asset;
import com.capgemini.assetmanagement.application.entity.Assets;

public interface AssetService {

	public List<Asset> getAllAssets();

	public Asset getAssetById(int theId);

	public Page<Assets> getAsset(int pageNo, int itemsPerPage);

	public Page<Assets> getSortAssets(int pageNo, int itemsPerPage, String fieldName);

	public void save(Assets assets);
	
	public Assets findById(int theId);

	public void deleteById(int theId);

}
