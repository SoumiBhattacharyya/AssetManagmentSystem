package com.capgemini.assetmanagement.application.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.Users;

public interface UserService {

	public void save(Users users);

	public Page<Users> getUser(int pageNo, int itemsPerPage);

	public Page<Users> getSortUsers(int pageNo, int itemsPerPage, String fieldName);

	public void deleteById(int theId);

	public User findByEmail(String email);

	public List<User> getAllUsers();

	public User getUserById(int theId);

	public List<User> getCustomers(String role);

	public User updateUser(int theId);

}
