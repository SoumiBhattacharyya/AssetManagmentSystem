package com.capgemini.assetmanagement.application.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestResponse<T> {

	private boolean error;
	private String message;
//	T data;
	private List<Request> data;
	private Request requests;

	public RequestResponse() {

	}

	public RequestResponse(boolean error, String message, List<Request> data, Request requests) {
		this.error = error;
		this.message = message;
		this.data = data;
		this.requests = requests;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Request> getData() {
		return data;
	}

	public void setData(List<Request> data) {
		this.data = data;
	}

	public Request getRequests() {
		return requests;
	}

	public void setRequests(Request requests) {
		this.requests = requests;
	}

	@Override
	public String toString() {
		return "RequestResponse [error=" + error + ", message=" + message + ", data=" + data + ", requests=" + requests
				+ "]";
	}
	
	

//	public T getData() {
//		return data;
//	}
//
//	public void setData(T data) {
//		this.data = data;
//	}

}
