package com.capgemini.assetmanagement.application.entity;

import java.io.Serializable;

public class JwtResponse implements Serializable {
	private static final long serialVersionUID = -8091879091924046844L;
	private final String token;
	private final String email;
	private final Boolean error;
	private final String role;
	private final Integer userId;

	public JwtResponse(String token, String email, String role, Boolean error, Integer userId) {
		this.token = token;
		this.email = email;
		this.error = error;
		this.role = role;
		this.userId = userId;
	}

	public String getToken() {
		return token;
	}

	public String getEmail() {
		return email;
	}

	public Boolean getError() {
		return error;
	}

	public String getRole() {
		return role;
	}

	public Integer getUserId() {
		return userId;
	}
	
	
	

}
