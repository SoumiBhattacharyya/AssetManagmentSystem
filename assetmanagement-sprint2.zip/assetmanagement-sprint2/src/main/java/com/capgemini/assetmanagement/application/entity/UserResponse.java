package com.capgemini.assetmanagement.application.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserResponse<T> {

	private boolean error;
	private String message;
//	T data;
	private List<User> data;
	private User users;

	public UserResponse(boolean error, String message, List<User> data, User users) {
		this.error = error;
		this.message = message;
		this.data = data;
		this.users = users;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<User> getData() {
		return data;
	}

	public void setData(List<User> data) {
		this.data = data;
	}

	public User getUsers() {
		return users;
	}

	public void setUsers(User users) {
		this.users = users;
	}

	@Override
	public String toString() {
		return "UserResponse [error=" + error + ", message=" + message + ", data=" + data + ", users=" + users + "]";
	}

}
