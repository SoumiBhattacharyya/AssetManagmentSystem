package com.capgemini.assetmanagement.application.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.capgemini.assetmanagement.application.DAO.RequestRepository;
import com.capgemini.assetmanagement.application.entity.Assets;
import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.Requests;
import com.capgemini.assetmanagement.application.exception.RequestNotFoundException;

@Service
public class RequestServiceImpl implements RequestService {

	private RequestRepository requestRepository;

	@Autowired
	public RequestServiceImpl(RequestRepository theRequestRepository) {
		requestRepository = theRequestRepository;
	}

	@Override
	public List<Request> findAll() {
		return requestRepository.findAll();
	}

	@Override
	public Request findById(int theId) {
		Optional<Request> result = requestRepository.findById(theId);

		Request theRequests = null;

		if (result.isPresent()) {
			theRequests = result.get();
		} else {
			// we didn't find the employee
			throw new RequestNotFoundException("Sorry ! No matching results found !");
		}

		return theRequests;
	}

	@Override
	public void save(Request requests) {
		requestRepository.save(requests);
	}

	@Override
	public void deleteById(int theId) {

		requestRepository.deleteById(theId);
	}

	@Override
	public List<Request> allocatedRequests(String alcUnlc) {

		return requestRepository.allocatedRequests(alcUnlc);
	}

	@Override
	public List<Request> unallocatedRequests(String alcUnlc) {

		return requestRepository.unallocatedRequests(alcUnlc);
	}

	@Override
	public Page<Request> getRequest(int pageNo, int itemsPerPage) {
		Pageable pageable = PageRequest.of(pageNo, itemsPerPage);

		return requestRepository.findAll(pageable);
	}

	@Override
	public Page<Request> getSortRequests(int pageNo, int itemsPerPage, String fieldName) {
		Pageable pageable = PageRequest.of(pageNo, itemsPerPage, Sort.by(fieldName));

		return requestRepository.findAll(pageable);
	}

	@Override
	public List<Request> getUserRequests(Integer theId) {
			return requestRepository.getUserRequests(theId);
	}


	@Override
	public Request validate(int theId) {
		
		return requestRepository.validate( theId);
	}

	@Override
	public Requests approval(int theId) {
		
		return requestRepository.approval(theId);
	}

	@Override
	public Requests rejection(int theId) {
		
		return requestRepository.rejection(theId);
	}


}
