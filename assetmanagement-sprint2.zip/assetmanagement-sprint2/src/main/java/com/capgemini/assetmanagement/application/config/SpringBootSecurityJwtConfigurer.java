package com.capgemini.assetmanagement.application.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.filter.OncePerRequestFilter;

import com.capgemini.assetmanagement.application.filter.CustomUsernamePasswordAuthenticationFilter;
import com.capgemini.assetmanagement.application.filter.JwtRequestFilter;
import com.capgemini.assetmanagement.application.springsecurity.RestAuthenticationEntryPoint;

@CrossOrigin(origins = "http://localhost:4200")
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringBootSecurityJwtConfigurer extends WebSecurityConfigurerAdapter {

	@Bean
	public PasswordEncoder getPasswordEncoder() {
		return new BCryptPasswordEncoder(12);

	}

//	@Autowired
	private RestAuthenticationEntryPoint restAuthenticationEntryPoint;

	@Bean
	public RestAuthenticationEntryPoint getRestAuthenticationEntryPoint() {
		return restAuthenticationEntryPoint;
	}

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private JwtRequestFilter jwtRequestFilter;

	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
	}// end of configureGlobal()

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.cors().and().csrf().disable().authorizeRequests()
				.antMatchers("/api/login", "/api/get-requests", "/api/get-assets", "/api/edit-users",
						"/api/delete-user/{userId}", "/api/get/{assetId}", "/api/users/get/{email}",
						"/api/get/user-requests/{userId}", "/api/add-requests", "/api/requests/get-assets/{theId}",
						"/api/requests/validate/{theId}", "/api/getAllRequests", "/api/request-approval/{theId}",
						"/api/request-rejection/{theId}","/api/get-customers/{role}")
				.permitAll().and().authorizeRequests().antMatchers("/api/requests/{requestId}").hasRole("MANAGER").and()
				.authorizeRequests()
				.antMatchers("/api/delete-request/{requestId}", "/api/add-assets", "/api/delete-assets/{assetId}",
						"/api/edit-requests", "/api/get-users",
						"/api/requests/get/unlc/{alcUnlc}","/api/requests/get/{alcUnlc}")
				.hasRole("ADMIN").anyRequest().authenticated().and().exceptionHandling()
				.authenticationEntryPoint(restAuthenticationEntryPoint).and().sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
				.addFilterBefore(jwtRequestFilter, CustomUsernamePasswordAuthenticationFilter.class);
	}

}// End of class
