package com.capgemini.assetmanagement.application.entity;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface RequestPaginationRepository extends PagingAndSortingRepository<Requests, Integer>{

}
