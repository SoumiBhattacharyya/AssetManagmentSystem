package com.capgemini.assetmanagement.application.entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class AssetResponse<T> {

	private boolean error;
	private String message;
//	T data;
	private List<Asset> data;
	private Asset assets;

	public AssetResponse(boolean error, String message, List<Asset> data, Asset assets) {

		this.error = error;
		this.message = message;
		this.data = data;
		this.assets = assets;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<Asset> getData() {
		return data;
	}

	public void setData(List<Asset> data) {
		this.data = data;
	}

	public Asset getAssets() {
		return assets;
	}

	public void setAssets(Asset assets) {
		this.assets = assets;
	}

	@Override
	public String toString() {
		return "AssetResponse [error=" + error + ", message=" + message + ", data=" + data + ", assets=" + assets + "]";
	}

}
