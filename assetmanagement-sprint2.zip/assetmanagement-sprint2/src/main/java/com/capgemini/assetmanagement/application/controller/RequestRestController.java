package com.capgemini.assetmanagement.application.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.assetmanagement.application.entity.Asset;
import com.capgemini.assetmanagement.application.entity.Assets;
import com.capgemini.assetmanagement.application.entity.Request;
import com.capgemini.assetmanagement.application.entity.RequestResponse;
import com.capgemini.assetmanagement.application.entity.Requests;
import com.capgemini.assetmanagement.application.entity.User;
import com.capgemini.assetmanagement.application.entity.Users;
import com.capgemini.assetmanagement.application.exception.AssetNotFoundException;
import com.capgemini.assetmanagement.application.exception.InsufficientAssetQuantity;
import com.capgemini.assetmanagement.application.exception.RequestNotFoundException;
import com.capgemini.assetmanagement.application.exception.UserNotFoundException;
import com.capgemini.assetmanagement.application.service.AssetService;
import com.capgemini.assetmanagement.application.service.RequestService;
import com.capgemini.assetmanagement.application.service.UserService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class RequestRestController {

	@Autowired
	private RequestService requestService;

//	@Autowired
//	private AssetRepository assetRepository;

	@Autowired
	private AssetService assetService;

//	@Autowired
//	private UserRepository userRepository;

	@Autowired
	private UserService userService;

	Assets assets;

	Requests requests;

	@Autowired
	public RequestRestController(RequestService theRequestService) {
		requestService = theRequestService;
	}

	// expose "/employees" and return list of students
	@GetMapping("/get-requests")
	public RequestResponse<List<Request>> findAll() {
		List<Request> list = requestService.findAll();
		if (list != null) {
			return new RequestResponse<List<Request>>(false, "Requests found!", list, null);
		} else {
			return new RequestResponse<List<Request>>(true, "Requests Not found!", null, null);
		}

	}

	@GetMapping("/get/user-requests/{userId}")
	public RequestResponse<List<Request>> getUserRequests(@PathVariable Integer userId) {
		List<Request> list = requestService.getUserRequests(userId);

		if (list.isEmpty()) {
			return new RequestResponse<List<Request>>(true, "No Requests Placed !", null, null);
		} else {
			return new RequestResponse<List<Request>>(false, "Requests found!", list, null);
		}

//		if (list == null) {
//			throw new RequestNotFoundException("No Requests placed !");
//		} else {
//			return new RequestResponse<List<Requests>>(false, "Requests found!", list);
//			
//		}

	}

	@GetMapping(value = "/requests/{requestId}", consumes = { "application/json" })
	public RequestResponse<Request> getRequest(@PathVariable int requestId) {

		Request theRequests = requestService.findById(requestId);

		if (theRequests != null) {
			return new RequestResponse<Request>(false, "Request found!", null, theRequests);
		} else {
			return new RequestResponse<Request>(true, "Request Not found!", null, null);
		}
	}

	@PostMapping(value = "/add-requests", consumes = { "application/json" })
	public RequestResponse<Request> addRequests(@RequestBody Request theRequests) {

		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update

		theRequests.setRequestId(0);

		theRequests.setStatus("Requested");

		requestService.save(theRequests);

		return new RequestResponse<Request>(false, "Request Added Successfully!", null, null);

	}

	@PutMapping("/edit-requests")
	public RequestResponse<Request> updateAsset(@RequestBody Request theRequests) {

		requestService.save(theRequests);

		return new RequestResponse<Request>(false, "Request Updated Successfully!", null, null);

	}

	@DeleteMapping("/requests/{requestId}")
	public RequestResponse<Request> deleteRequest(@PathVariable int requestId) {

		Request tempRequests = requestService.findById(requestId);

		// throw exception if null

		if (tempRequests != null) {
			requestService.deleteById(requestId);
			return new RequestResponse<Request>(false, "Request Deleted Successfully!", null, null);
		} else {
			throw new RequestNotFoundException("Request to be deleted is not found!");

		}
	}

	@GetMapping("/requests/get/{alcUnlc}")
	public RequestResponse<List<Request>> allocatedRequests(@PathVariable String alcUnlc) {

		List<Request> list = requestService.allocatedRequests(alcUnlc);

		if (list != null) {
			return new RequestResponse<List<Request>>(false, "Allocated Requests found !", list, null);
		} else {
			throw new RequestNotFoundException("Allocated Requests Not Found !");
		}

	}

	@GetMapping("/requests/get/unlc/{alcUnlc}")
	public RequestResponse<List<Request>> unallocatedRequests(@PathVariable String alcUnlc) {

		List<Request> list = requestService.unallocatedRequests(alcUnlc);

		if (list != null) {
			return new RequestResponse<List<Request>>(false, "Un-Allocated Requests found !", list, null);
		} else {
			throw new RequestNotFoundException("Un-Allocated Requests Not Found !");
		}

	}

	@GetMapping("/requests/{pageNo}/{itemsPerPage}")
	public Page<Request> getAssets(@PathVariable int pageNo, @PathVariable int itemsPerPage) {
		return requestService.getRequest(pageNo, itemsPerPage);
	}

	@GetMapping("/requests/{pageNo}/{itemsPerPage}/{fieldName}")
	public Page<Request> getSortRequests(@PathVariable int pageNo, @PathVariable int itemsPerPage,
			@PathVariable String fieldName) {
		return requestService.getSortRequests(pageNo, itemsPerPage, fieldName);
	}

	@GetMapping("/requests/validate/{theId}")
	public RequestResponse<Request> validate(@PathVariable int theId) {

		int count = 0;
//		Assets assets = new Assets();

		Request theRequests = requestService.findById(theId);
		System.out.println(theRequests.getAssetId());

		Asset demo1 = assetService.getAssetById(theRequests.getAssetId());
		System.out.println(demo1.getAssetName());

		User demo2 = userService.getUserById(theRequests.getUserId());
		System.out.println(demo2.getUserId());
		
		

		if (theRequests.getStatus().equalsIgnoreCase("Requested")){
			
		
			List<User> list = userService.getAllUsers();
//			System.out.println(list.size());
			for (int i = 0; i < list.size(); i++) {
				if (theRequests.getEmployeeId() == list.get(i).getUserId()
						&& list.get(i).getRole().equals("CUSTOMER")) {
					count++;
				}
			}
			if (count == 0) {
				throw new UserNotFoundException("Sorry not a registered customer !");
			}

			if (theRequests.getAssetId() != demo1.getAssetId()) {
				return new RequestResponse<Request>(true, "Invalid Asset Id !", null, null);
			} else if (!theRequests.getAssetName().equalsIgnoreCase(demo1.getAssetName())) {
				return new RequestResponse<Request>(true, "Invalid Asset Name !", null, null);
			} else if (theRequests.getAssetQuantity() > demo1.getAssetQuantity()) {
				return new RequestResponse<Request>(true, "Requested number of stock not available !", null, null);
			} else if (theRequests.getUserId() != demo2.getUserId()) {
				return new RequestResponse<Request>(true, "Sorry Invalid User Id !", null, null);
			} else {
				theRequests.setStatus("Processing");
				requestService.save(theRequests);
				return new RequestResponse<Request>(false, "Request maybe Allotted !", null, null);
			}

		}else if(theRequests.getStatus().equalsIgnoreCase("Processing")) {
			return new RequestResponse<Request>(true, "Request is fit to be Allocated !", null, null);
		}else if (theRequests.getAlcUnlc().equalsIgnoreCase("Allocated") && theRequests.getStatus().equalsIgnoreCase("Processed")) {
			return new RequestResponse<Request>(true, "Request is already Allocated !", null, null);
		} else if (theRequests.getAlcUnlc().equalsIgnoreCase("Un-Allocated") && theRequests.getStatus().equalsIgnoreCase("Processed")) {
			return new RequestResponse<Request>(true, "Request is already Un-Allocated !", null, null);
		}
		return new RequestResponse<Request>(true, "Sorry ! Request cannot be Approved !", null, null);
	}

	@GetMapping("/request-approval/{theId}")
	public RequestResponse<Request> approval(@PathVariable int theId) {

		int count = 0;

		Request demo = requestService.findById(theId);

		Assets demo1 = assetService.findById(demo.getAssetId());
		
		
		 if (demo.getStatus().equalsIgnoreCase("Processing")){

//		Assets forSave = assetService.save(demo1);

		List<User> list = userService.getAllUsers();
		System.out.println(list.size());
		for (int i = 0; i < list.size(); i++) {
			if (demo.getEmployeeId() == list.get(i).getUserId() && list.get(i).getRole().equals("CUSTOMER")) {
				count++;
			}
		}

		if (demo.getAssetId() == demo1.getAssetId() && demo.getAssetName().equalsIgnoreCase(demo1.getAssetName())
				&& demo.getAssetQuantity() <= demo1.getAssetQuantity() && count != 0) {
			demo.setStatus("Processed");
			demo.setAlcUnlc("Allocated");
			demo.setReason("Your Request has been approved and allocated !");

			if (demo.getAlcUnlc().equalsIgnoreCase("Allocated")) {
				Integer requestQuant = demo.getAssetQuantity();
				Integer assetQuant = demo1.getAssetQuantity();
				demo1.setAssetQuantity(assetQuant - requestQuant);

				Double price = demo1.getAssetPrice();
				Double totalPrice = price * assetQuant;
				demo.setTotalPrice(totalPrice);
			}
			requestService.save(demo);
			assetService.save(demo1);
			return new RequestResponse<Request>(false, "Request is Approved !", null, null);

		} 
		}else if (demo.getStatus().equalsIgnoreCase("Requested")) {
			return new RequestResponse<Request>(true, "Request is yet to be validated , please validate the request !", null, null);
		}else if (demo.getAlcUnlc().equalsIgnoreCase("Allocated") && demo.getStatus().equalsIgnoreCase("Processed")) {
			return new RequestResponse<Request>(true, "Request is already Allocated !", null, null);
		} else if (demo.getAlcUnlc().equalsIgnoreCase("Un-Allocated") && demo.getStatus().equalsIgnoreCase("Processed")) {
			return new RequestResponse<Request>(true, "Request is already Un-Allocated !", null, null);
		}
		return new RequestResponse<Request>(true, "Sorry ! Request cannot be Approved !", null, null);
		
	}

	@GetMapping("/request-rejection/{theId}")
	public RequestResponse<Request> rejection(@PathVariable int theId) {

		int count = 0;

		Request theRequests = requestService.findById(theId);
//		System.out.println(theRequests.getAssetId());

		Asset demo1 = assetService.getAssetById(theRequests.getAssetId());
//		System.out.println(demo1.getAssetName());

		User demo2 = userService.getUserById(theRequests.getUserId());
//		System.out.println(demo2.getUserId());
	
		
		if(theRequests.getStatus().equals("Processing") || theRequests.getStatus().equals("Requested")) {
		
		theRequests.setStatus("Processed");
		theRequests.setAlcUnlc("Un-allocated");

		List<User> list = userService.getAllUsers();
		System.out.println(list.size());
		for (int i = 0; i < list.size(); i++) {
			if (theRequests.getEmployeeId() == list.get(i).getUserId() && list.get(i).getRole().equals("CUSTOMER")) {
				count++;
			}
		}
		if (count == 0) {
			theRequests.setReason("Sorry not a registered customer !");
		} else if (theRequests.getAssetId() != demo1.getAssetId()) {
			theRequests.setReason("Invalid Asset Id !");
		} else if (!theRequests.getAssetName().equalsIgnoreCase(demo1.getAssetName())) {
			theRequests.setReason("Invalid Asset Name !");
		} else if (theRequests.getAssetQuantity() > demo1.getAssetQuantity()) {
			theRequests.setReason("Requested number of stock not available !");
		} else if (theRequests.getUserId() != demo2.getUserId()) {
			theRequests.setReason("Sorry Invalid User Id !");
		} else {
			theRequests.setStatus("Processed");
			theRequests.setReason(
			
					"Your request order could not be fulfilled presently , Sorry for the inconvenience caused !");

		}
		theRequests.setTotalPrice(0.0);
		requestService.save(theRequests);
		
	}else if (theRequests.getAlcUnlc().equalsIgnoreCase("Allocated") && theRequests.getStatus().equalsIgnoreCase("Processed")) {
		return new RequestResponse<Request>(true, "Request is already Allocated !", null, null);
	} else if (theRequests.getAlcUnlc().equalsIgnoreCase("Un-Allocated") && theRequests.getStatus().equalsIgnoreCase("Processed")) {
		return new RequestResponse<Request>(true, "Request is already Un-Allocated !", null, null);
	}
		return new RequestResponse<Request>(true, "Sorry ! Request cannot be Approved !", null, null);
	}
	
}
