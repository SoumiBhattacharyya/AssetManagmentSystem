package com.capgemini.assetmanagement.application.entity;
//package com.capgemini.assetmanagement.application.entity;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.capgemini.assetmanagement.application.service.JwtTokenUtil;
//
//public class Login {
//
//	private Integer userId;
//
//	private String password;
//	
//	private final String jwttoken;
//
//	public Login() {
//
//	}
//
//	public Integer getUserId() {
//		return userId;
//	}
//
//	public void setUserId(Integer userId) {
//		this.userId = userId;
//	}
//
//	public String getPassword() {
//		return password;
//	}
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//	public String getJwttoken() {
//		return jwttoken;
//	}
//
//	@Override
//	public String toString() {
//		return "Login [userId=" + userId + ", password=" + password + ", jwttoken=" + jwttoken + "]";
//	}
//
//	
//
//}
